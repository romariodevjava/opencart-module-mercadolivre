<?php
// Heading

$_['authentication_url']                           = '%smodule_mercadolivre';

// Text