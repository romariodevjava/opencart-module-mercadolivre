function createSelectOptions(options, value, description, $select) {
    $select.html('<option value="">{{ entry_select }}</option>');
    var valueSelected = $select.data('value');

    $.each(options, function (i, v) {
        $select.append(`<option value="${v[value]}" ${valueSelected == v[value] ? 'selected' : ''}>${v[description]}</option>`);
    });
}